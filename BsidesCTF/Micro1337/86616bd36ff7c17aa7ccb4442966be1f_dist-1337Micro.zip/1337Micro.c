/*
 * CTF Challenge By Jordan
 * 
 */


#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/mman.h>
#include <string.h>
#include <unistd.h>


#define TAPE_LEN 100
#define LEET 133

#define RED  "\033[91m"
#define GREEN  "\033[92m"
#define BLUE "\033[0;94m"
#define GREY "\033[0;97m"
#define YELLOW  "\033[93m"
#define PINK  "\033[95m"
#define LIGHT_RED "\033[1;31m"
#define LIGHT_BLUE "\033[0;96m"
#define LIGHT_PINK  "\033[94m"
#define END  "\033[0m"

#define MENU_COLOUR LIGHT_BLUE

#define TRUE 1
#define FALSE 0
#define OFFSET 'A'

#define NUM_FUNCS 19
void quit(unsigned char *ptr);
void inc_r1(unsigned char *ptr);
void dec_r1(unsigned char *ptr);
void inc_r2(unsigned char *ptr);
void dec_r2(unsigned char *ptr);
void set(unsigned char *ptr);
void set_word(unsigned char *ptr);
void get(unsigned char *ptr);
void get_word(unsigned char *ptr);
void load_r1(unsigned char *ptr);
void load_r1_word(unsigned char *ptr);
void print(unsigned char *ptr);
void swap(unsigned char *ptr);
void je(unsigned char *ptr);
void jz(unsigned char *ptr);
void jmp(unsigned char *ptr);
void add(unsigned char *ptr);
void printFlag(unsigned char *ptr);
void printMemory(unsigned char *ptr);
void printRegisters(void);

void printTape(void);

#define NUM_FLAGS 5
char* protectedFlags[NUM_FLAGS];

int r1;
int r2;
int ip;

int constVal;
int guessVal;

unsigned char tape[TAPE_LEN+1];

void (*funcs[NUM_FUNCS])(unsigned char *ptr) = { 
	inc_r1,
	dec_r1,
	inc_r2,
	dec_r2,
	printMemory,
	printFlag,
	get,
	get_word,
	je,
	jmp,
	jz,
	load_r1,
	load_r1_word,
	add,
	swap,
	print,
	quit,
	set,
	set_word
};


#define INDEX_inc_r1 0
#define INDEX_dec_r1 1
#define INDEX_inc_r2 2
#define INDEX_dec_r2 3
#define INDEX_printMemory 4
#define INDEX_printFlag 5
#define INDEX_get 6
#define INDEX_get_word 7
#define INDEX_je 8
#define INDEX_jmp 9
#define INDEX_jz 10
#define INDEX_load_r1 11
#define INDEX_load_r1_word 12
#define INDEX_add 13
#define INDEX_swap 14
#define INDEX_print 15
#define INDEX_quit 16
#define INDEX_set 17
#define INDEX_set_word 18

char flags[NUM_FLAGS][80] = {
    "FLAG 0 placeholder",
    "FLAG 1 placeholder",
    "FLAG 2 placeholder",
    "FLAG 3 placeholder",
    "FLAG 4 placeholder"
};

void setup_flags() {
	strcpy(flags[0], getenv("FLAG0"));
	strcpy(flags[1], getenv("FLAG1"));
	strcpy(flags[2], getenv("FLAG2"));
	strcpy(flags[3], getenv("FLAG3"));
	strcpy(flags[4], getenv("FLAG4"));
    for (int i = 0; i < NUM_FLAGS; i++) {
        // Allocate memory for each flag.
        protectedFlags[i] = mmap(NULL, strlen(flags[i]) + 1, PROT_WRITE , MAP_ANONYMOUS | MAP_PRIVATE, -1, 0);
        if (protectedFlags[i] == MAP_FAILED) {
            perror("mmap");
            return;
        }

        // Copy each flag to the allocated memory.
        strcpy(protectedFlags[i], flags[i]);

        // Protect the flag (make it non-readable).
        if (mprotect(protectedFlags[i], strlen(flags[i]) + 1, 0) == -1) {
            perror("mprotect");
            return;
        }

        // Clear the original flag string.
        memset(flags[i], 0x41, sizeof(flags[i]));
    }
}

void cleanup_flags() {
    for (int i = 0; i < NUM_FLAGS; i++) {
        if (protectedFlags[i]) {
            munmap(protectedFlags[i], strlen(protectedFlags[i]) + 1);
            protectedFlags[i] = NULL;
        }
    }
}

int getRandomValue() {
    static int initialized = 0;
    static int staticVal;
    if (!initialized) {
        staticVal = rand();
        initialized = 1;
    }
    return staticVal;
}

int main(int argc, char *argv[]){
	setbuf(stdout, NULL);
	setbuf(stdin, NULL);
	setbuf(stderr, NULL);
	srand(time(NULL));
	guessVal = 0;
	constVal = atoi(getenv("CONSTVAL"));
	setup_flags(); 
	
	ip = 0;
	r1 = 0;
	r2 = 0;
	int o = OFFSET;
	printf("-------------------------\n");
	printf("| %c | inc_r1           |"MENU_COLOUR" Increment r1\n" END, o++);
	printf("| %c | dec_r1           |"MENU_COLOUR" Decrement r1\n" END, o++);
	printf("| %c | inc_r2           |"MENU_COLOUR" Increment r2\n" END, o++);
	printf("| %c | dec_r2           |"MENU_COLOUR" Decrement r2\n" END, o++);
	printf("| %c | printMemory      |"MENU_COLOUR" Print current memory state\n" END, o++);
	printf("| %c | printFlag        |"MENU_COLOUR" Attempt to print flags\n" END, o++);
	printf("| %c | get              |"MENU_COLOUR" Load r2 with value at tape[r1] (as char)\n" END, o++);
	printf("| %c | get_word         |"MENU_COLOUR" Load r2 with value at tape[r1] (as int)\n" END, o++);
	printf("| %c | je               |"MENU_COLOUR" Jump to tape[ip] if r1 equals r2 \t\t;ip+=1\n" END, o++);
	printf("| %c | jmp              |"MENU_COLOUR" Jump to tape[ip]\n" END, o++);
	printf("| %c | jz               |"MENU_COLOUR" Jump to tape[ip] if r2 is zero \t\t;ip+=1\n" END, o++);
	printf("| %c | load_r1          |"MENU_COLOUR" Load r1 with the next byte from tape[ip] \t;ip+=1\n" END, o++);
	printf("| %c | load_r1_word     |"MENU_COLOUR" Load r1 with the next 4 bytes from tape[ip] \t;ip+=4\n" END, o++);
	printf("| %c | add              |"MENU_COLOUR" Add r2 to r1\n" END, o++);
	printf("| %c | swap             |"MENU_COLOUR" Swap values of r1 and r2\n" END, o++);
	printf("| %c | print            |"MENU_COLOUR" Print from tape[ip] \n" END, o++);
	printf("| %c | quit             |"MENU_COLOUR" Exit with status code in tape[ip]\n" END, o++);
	printf("| %c | set              |"MENU_COLOUR" Set tape[r1] = r2 (as char)\n" END, o++);
	printf("| %c | set_word         |"MENU_COLOUR" Set tape[r1] = r2 (as int)\n" END, o++);
	printf("-------------------------\n");
	printf("Enter Program Bytes\n");
	read(0, tape, TAPE_LEN);

	printTape();
	while(TRUE){
		if (tape[ip] == '\n'){
			printRegisters();
			printf("Bye :)\n");
			return EXIT_SUCCESS;
		}
		if (tape[ip] < OFFSET || tape[ip] >= OFFSET+NUM_FUNCS){
			printf("INVALID 1337 CODE\n");
			return EXIT_FAILURE;
		}
		printRegisters();
		// Each func takes the r1'th cell ptr in the tape as its only arg.
		funcs[tape[ip++]-OFFSET](tape + r1);
	}
	cleanup_flags();
	return EXIT_SUCCESS;
}

// Exit with status code tape[ip].
void quit(unsigned char *ptr){
	printf("%c:quit()\n", OFFSET+INDEX_quit);
	exit((int)*ptr);
}

void inc_r1(unsigned char *ptr){
	printf("%c:inc_r1()\n", OFFSET+INDEX_inc_r1);
	r1 += 1;
}

void dec_r1(unsigned char *ptr){
	printf("%c:dec_r1()\n", OFFSET+INDEX_dec_r1);
	r1 -= 1;
}

void inc_r2(unsigned char *ptr){
	printf("%c:inc_r2()\n", OFFSET+INDEX_inc_r2);
	r2 += 1;
}

void dec_r2(unsigned char *ptr){
	printf("%c:dec_r2()\n", OFFSET+INDEX_dec_r2);
	r2 -= 1;
}

void set(unsigned char *ptr){
	printf("%c:set() \t\t tape[r1] = r2\n", OFFSET+INDEX_set);
	*ptr = r2;
}

void set_word(unsigned char *ptr){
	printf("%c:set_word() \t\t tape[r1] = r2\n", OFFSET+INDEX_set_word);
	unsigned int *n = (unsigned int *)ptr;
	*n = r2;
}

void get(unsigned char *ptr){
	printf("%c:get() \t\t r2 = tape[r1]\n", OFFSET+INDEX_get);
	r2 = *ptr;
}

void get_word(unsigned char *ptr){
	printf("%c:get_word() \t\t r2 = tape[r1]\n", OFFSET+INDEX_get_word);
	unsigned int *n = (unsigned int *)ptr;
	r2 = *n;
}

void load_r1(unsigned char *ptr){
	printf("%c:load_r1() \t\t r1 = tape[ip++]\n", OFFSET+INDEX_load_r1);
	r1 = *(tape + ip++);
}

void load_r1_word(unsigned char *ptr){
	printf("%c:load_r1_word() \t r1 = tape[ip] \t\t;ip+=4\n", OFFSET+INDEX_load_r1_word);
	unsigned int *n = (unsigned int *)(tape + ip);
	ip += 4;
	r1 = *n;
}

void print(unsigned char *ptr){
	printf("%c:print(tape[r1])\n", OFFSET+INDEX_print);
	printf("%s\n", ptr); 
}

void swap(unsigned char *ptr){
	printf("%c:swap()\n", OFFSET+INDEX_swap);
	int tmp = r1;
	r1 = r2;
	r2 = tmp;
}

void je(unsigned char *ptr){
	printf("%c:je() \t if (r1 == r2) { ip = tape[ip] } else { ip+=1 }\n", OFFSET+INDEX_je);
	if (r2 == r1){
		ip = *(tape + ip);
	}else{
		ip++;
	}
}

void jz(unsigned char *ptr){
	printf("%c:jz() \t if (r2 == 0) { ip = tape[ip] } else { ip+=1 }n", OFFSET+INDEX_jz);
	if (r2 == 0){
		ip = *(tape + ip);
	}else{
		ip++;
	}
}

void jmp(unsigned char *ptr){
	printf("%c:jmp() \t ip = tape[ip]\n", OFFSET+INDEX_jmp);
	ip = *(tape + ip );
}

void add(unsigned char *ptr){
	printf("%c:add() \t\t r1 = r1 + r2\n", OFFSET+INDEX_add);
	r1 = r1 + r2;
}

void printFlag(unsigned char *ptr){
	printf("%c:printFlag() current guess %d\n", OFFSET+INDEX_printFlag, guessVal);

	// Increment r1 to 7 to get this flag.
	if (r1 == 7) {
		if (mprotect(protectedFlags[0], sysconf(_SC_PAGESIZE), PROT_READ ) == -1) {
            perror("mprotect");
            return;
        }
        printf("%s\n", protectedFlags[0]);
		if (mprotect(protectedFlags[0], sysconf(_SC_PAGESIZE), 0) == -1) {
            perror("mprotect");
            return;
        }
	}

	// Load 0x1337 into r1 to get this flag.
	if (r1 == 0x1337) {
		if (mprotect(protectedFlags[1], sysconf(_SC_PAGESIZE), PROT_READ) == -1) {
			perror("mprotect");
			return;
		}
		printf("%s\n", protectedFlags[1]);
		if (mprotect(protectedFlags[1], sysconf(_SC_PAGESIZE), 0) == -1) {
			perror("mprotect");
			return;
		}
	}

	// Deduce where this value is and override it.
	if (guessVal == 1) {
		if (mprotect(protectedFlags[2], sysconf(_SC_PAGESIZE), PROT_READ) == -1) {
			perror("mprotect");
			return;
		}
		printf("%s\n", protectedFlags[2]);
		if (mprotect(protectedFlags[2], sysconf(_SC_PAGESIZE), 0) == -1) {
			perror("mprotect");
			return;
		}
	}

	if (guessVal == getRandomValue()) {
		if (mprotect(protectedFlags[3], sysconf(_SC_PAGESIZE), PROT_READ) == -1) {
			perror("mprotect");
			return;
		}
		printf("%s\n", protectedFlags[3]);
		if (mprotect(protectedFlags[3], sysconf(_SC_PAGESIZE), 0) == -1) {
			perror("mprotect");
			return;
		}
	}

	// Deduce where the random Val is, read it and set guessVal to that.
	if (guessVal == constVal) {
		if (mprotect(protectedFlags[4], sysconf(_SC_PAGESIZE), PROT_READ) == -1) {
			perror("mprotect");
			return;
		}
		printf("%s\n", protectedFlags[4]);
		if (mprotect(protectedFlags[4], sysconf(_SC_PAGESIZE), 0) == -1) {
			perror("mprotect");
			return;
		}
	}
}

void printMemory(unsigned char *ptr){
	printf("%c:printMemory()\n", OFFSET+INDEX_printMemory);
	printTape();
}

void printTape(void){
	printf("TAPE:\n");
	int i = 0;
	for (i = 0; i < TAPE_LEN; ++i){
		if (i == ip){	
			printf(PINK "%02x:" END, i);
		}else{
			printf(LIGHT_BLUE "%02x:" END, i);
		}

		if(tape[i] == 0){
			printf(GREY);
		}else if(tape[i] >0 && tape[i] < 5){
			printf(GREEN);
		}else if(tape[i] >=5 && tape[i] < 9){
			printf(BLUE);
		}else if(tape[i] >=9 && tape[i] < OFFSET){
			printf(LIGHT_RED);
		}else if(tape[i] >=OFFSET && tape[i] < OFFSET+NUM_FUNCS){
			printf(RED);
		}else if(tape[i] >= OFFSET+NUM_FUNCS){
			printf(LIGHT_PINK);
		}

		if (tape[i] >= OFFSET && tape[i] < OFFSET+NUM_FUNCS){
			printf("%02c " END, tape[i]);
		}else{
			printf("%02hhx " END, tape[i]);
		}

		if (i>0 && i%0x10 == 0x0f){	
			printf("\n");
		}else{
			printf("\t");
		}
	}
	printf("\n");
}

void printRegisters(void){
	printf("R1: %08x R2: %08x " PINK "IP: %08x\t\t" END , r1, r2, ip);
}



