#!/usr/bin/python3

# this is a starting place for exploiting the 1337 Microprocessor
# it has some helpful functions
# Compile source with: $ gcc 1337Micro.c -o 1337Micro -m32
# use like this:
# (./helper.py ; cat ) | ./1337Micro


import subprocess
import sys
from struct import pack

# -------------------------
# | A | inc_r1           | Increment r1
# | B | dec_r1           | Decrement r1
# | C | inc_r2           | Increment r2
# | D | dec_r2           | Decrement r2
# | E | printMemory      | Print current memory state
# | F | printFlag        | Attempt to print flags
# | G | get              | Load r2 with value at tape[r1] (as char)
# | H | get_word         | Load r2 with value at tape[r1] (as int)
# | I | je               | Jump to tape[ip] if r1 equals r2 		;ip+=1
# | J | jmp              | Jump to tape[ip]
# | K | jz               | Jump to tape[ip] if r2 is zero 		;ip+=1
# | L | load_r1          | Load r1 with the next byte from tape[ip] 	;ip+=1
# | M | load_r1_word     | Load r1 with the next 4 bytes from tape[ip] 	;ip+=4
# | N | add              | Add r2 to r1
# | O | swap             | Swap values of r1 and r2
# | P | print            | Print from tape[ip]
# | Q | quit             | Exit with status code in tape[ip]
# | R | set              | Set tape[r1] = r2 (as char)
# | S | set_word         | Set tape[r1] = r2 (as int)
# -------------------------

# Wrappers 
inc_r1 = b"A" 
dec_r1 = b"B" 
inc_r2 = b"C" 
dec_r2 = b"D" 
printMemory = b"E" 
printFlag = b"F" 
get = b"G" 
get_word = b"H" 
je = lambda addr: b"I" + chr(addr)
jmp = lambda addr: b"J" + chr(addr)
jz = lambda addr: b"K" + chr(addr)
load_r1 = lambda r1: b"L" + r1.to_bytes(1, byteorder='little', signed=True)
load_r1_word = lambda r1: b"M" + r1.to_bytes(4, byteorder='little', signed=False)
load_r1_word_signed = lambda r1:  b"M"  +  r1.to_bytes(4, byteorder='little', signed=True)
add = b"N" 
swap = b"O" 
print_f =  b"P"
quit = b"Q" 
set_f = b"R"
set_word = b"S" 


 #  Helpers
load_r2 = lambda r2: swap + load_r1(r2) + swap
load_r2_word = lambda r2: swap + load_r1_word(r2) + swap
save_r1 = lambda addr: swap + load_r1(addr) + set_f + swap # lose r2
save_r1_word = lambda addr: swap + load_r1_word(addr) + set_word + swap # lose r2
save_r1_word_signed = lambda addr: swap + load_r1_word_signed(addr) + set_word + swap # lose r2
 #  Helpers
load_r2 = lambda r2: swap + load_r1(r2) + swap
load_r2_word = lambda r2: swap + load_r1_word(r2) + swap
save_r1 = lambda addr: swap + load_r1(addr) + set_f + swap # lose r2
save_r1_word = lambda addr: swap + load_r1_word(addr) + set_word + swap # lose r2
save_r1_word_signed = lambda addr: swap + load_r1_word_signed(addr) + set_word + swap # lose r2


# Addresses (the lazy way)
odump = subprocess.check_output("objdump -x ./1337Micro | grep funcs", shell=True).decode()
funcs = int("0x" + odump[:odump.index(' ')], 16)
# print(f"funcs = {hex(funcs)}")

odump = subprocess.check_output("objdump -x ./1337Micro | grep tape", shell=True).decode()
tape_addr = int("0x" + odump[:odump.index(' ')], 16)
# print(f"tape_addr = {hex(tape_addr)}")


tape = []

tape.append(inc_r1)
tape.append(dec_r1)
tape.append(inc_r1)
tape.append(dec_r1)

sys.stdout.buffer.write(b''.join(tape) + b"\n")
